import { useEffect, useState, type FormEvent } from "react";
import { Wallet, Plus, Trash2, CreditCard, Check, ReceiptText, X } from "lucide-react";
import { supabase } from "../supabase";
import type { Profile, Student, FeeItem, Payment } from "../types";
import { TERMS, SESSIONS, CURRENT_SESSION, formatMoney, generateReference, fullName } from "../lib/school";
import { useClasses, className, fetchStudents, fetchMyChildren } from "../lib/data";
import {
  PageHeader, Card, Banner, Spinner, Field, fieldCls,
  Avatar, EmptyState, friendlyError, StatCard,
} from "../components/ui";

/*
 * Online payments: payments made here are recorded instantly with a reference.
 * To collect real card payments, connect a Paystack/Flutterwave account —
 * drop your public key into PAYSTACK_PUBLIC_KEY in this file and the gateway
 * checkout can be enabled at the marked spot in the Pay modal.
 */
const PAYSTACK_PUBLIC_KEY = "";

export function FeesScreen({ profile }: { profile: Profile }) {
  const isAdmin = profile.role === "super_admin" || profile.role === "admin";
  return isAdmin ? <AdminFees profile={profile} /> : <ParentFees profile={profile} />;
}

/* ---------------------------------- Admin ---------------------------------- */
function AdminFees({ profile }: { profile: Profile }) {
  const { classes } = useClasses();
  const [session, setSession] = useState(CURRENT_SESSION);
  const [items, setItems] = useState<FeeItem[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [students, setStudents] = useState<Student[]>([]);
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState<{ type: "err" | "ok"; text: string } | null>(null);

  // fee item form
  const [title, setTitle] = useState("");
  const [amount, setAmount] = useState("");
  const [feeClass, setFeeClass] = useState("");
  const [feeTerm, setFeeTerm] = useState<string>(TERMS[0]);
  const [saving, setSaving] = useState(false);

  // manual payment form
  const [payStudent, setPayStudent] = useState("");
  const [payAmount, setPayAmount] = useState("");
  const [payMethod, setPayMethod] = useState("Bank Transfer");
  const [recording, setRecording] = useState(false);

  const load = async () => {
    const [{ data: fi }, { data: pm }, allStudents] = await Promise.all([
      supabase.from("fee_items").select("*").order("created_at", { ascending: false }),
      supabase.from("payments").select("*").order("created_at", { ascending: false }).limit(100),
      fetchStudents(),
    ]);
    setItems(((fi ?? []) as FeeItem[]).filter((f) => f.session === session));
    setPayments((pm ?? []) as Payment[]);
    setStudents(allStudents);
    setLoading(false);
  };
  useEffect(() => { load(); }, [session]); // eslint-disable-line react-hooks/exhaustive-deps

  const studentName = (id: string) => {
    const s = students.find((x) => x.id === id);
    return s ? fullName(s) : "—";
  };

  const collected = payments.filter((p) => p.status === "Paid").reduce((a, p) => a + Number(p.amount), 0);

  const addItem = async (e: FormEvent) => {
    e.preventDefault();
    setSaving(true); setMsg(null);
    const { error } = await supabase.from("fee_items").insert({
      title: title.trim(), amount: Number(amount), class_id: feeClass || null, term: feeTerm, session,
    });
    setSaving(false);
    if (error) setMsg({ type: "err", text: friendlyError(error.message) });
    else { setTitle(""); setAmount(""); setMsg({ type: "ok", text: "Fee added." }); load(); }
  };

  const deleteItem = async (item: FeeItem) => {
    if (!window.confirm(`Delete fee "${item.title}"?`)) return;
    const { error } = await supabase.from("fee_items").delete().eq("id", item.id);
    if (error) setMsg({ type: "err", text: friendlyError(error.message) });
    else load();
  };

  const recordPayment = async (e: FormEvent) => {
    e.preventDefault();
    setRecording(true); setMsg(null);
    const { error } = await supabase.from("payments").insert({
      student_id: payStudent, amount: Number(payAmount), method: payMethod,
      reference: generateReference(), status: "Paid", paid_by: profile.id,
    });
    setRecording(false);
    if (error) setMsg({ type: "err", text: friendlyError(error.message) });
    else { setPayAmount(""); setMsg({ type: "ok", text: "Payment recorded." }); load(); }
  };

  return (
    <div>
      <PageHeader
        title="School Fees"
        subtitle="Set up fees and track payments"
        actions={
          <select className={fieldCls + " w-44"} value={session} onChange={(e) => setSession(e.target.value)}>
            {SESSIONS.map((s) => <option key={s}>{s}</option>)}
          </select>
        }
      />
      <div className="space-y-4">
        <Banner msg={msg} />
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
          <StatCard label="Fees Collected (all time)" value={formatMoney(collected)} icon={Wallet} tint="bg-purple-50 text-purple-700" />
          <StatCard label="Payments Recorded" value={payments.length} icon={ReceiptText} tint="bg-blue-50 text-[#0a4da8]" />
          <StatCard label={`Fee Items (${session})`} value={items.length} icon={CreditCard} tint="bg-emerald-50 text-emerald-700" />
        </div>

        <div className="grid lg:grid-cols-5 gap-4 items-start">
          <div className="lg:col-span-2 space-y-4">
            <Card className="p-6">
              <h3 className="font-bold text-slate-900 mb-4">Add Fee — {session}</h3>
              <form onSubmit={addItem} className="space-y-4">
                <Field label="Fee Title"><input required className={fieldCls} placeholder="e.g. School Fees, PTA Levy" value={title} onChange={(e) => setTitle(e.target.value)} /></Field>
                <Field label="Amount (₦)"><input required type="number" min={0} className={fieldCls} placeholder="85000" value={amount} onChange={(e) => setAmount(e.target.value)} /></Field>
                <div className="grid grid-cols-2 gap-3">
                  <Field label="Applies To">
                    <select className={fieldCls} value={feeClass} onChange={(e) => setFeeClass(e.target.value)}>
                      <option value="">All Classes</option>
                      {classes.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                    </select>
                  </Field>
                  <Field label="Term">
                    <select className={fieldCls} value={feeTerm} onChange={(e) => setFeeTerm(e.target.value)}>
                      {TERMS.map((t) => <option key={t}>{t}</option>)}
                      <option value="">Whole Session</option>
                    </select>
                  </Field>
                </div>
                <button disabled={saving} className="inline-flex items-center gap-2 bg-[#0a4da8] hover:bg-[#083d86] disabled:opacity-70 text-white rounded-lg px-4 py-2.5 text-sm font-medium">
                  {saving ? <Spinner /> : <Plus className="w-4 h-4" />} Add Fee
                </button>
              </form>
            </Card>

            <Card className="p-6">
              <h3 className="font-bold text-slate-900 mb-4">Record Offline Payment</h3>
              <form onSubmit={recordPayment} className="space-y-4">
                <Field label="Student">
                  <select required className={fieldCls} value={payStudent} onChange={(e) => setPayStudent(e.target.value)}>
                    <option value="">Select student…</option>
                    {students.filter((s) => s.status === "active").map((s) => (
                      <option key={s.id} value={s.id}>{fullName(s)} — {className(classes, s.class_id)}</option>
                    ))}
                  </select>
                </Field>
                <div className="grid grid-cols-2 gap-3">
                  <Field label="Amount (₦)"><input required type="number" min={1} className={fieldCls} value={payAmount} onChange={(e) => setPayAmount(e.target.value)} /></Field>
                  <Field label="Method">
                    <select className={fieldCls} value={payMethod} onChange={(e) => setPayMethod(e.target.value)}>
                      <option>Bank Transfer</option><option>Cash</option><option>POS</option><option>Cheque</option>
                    </select>
                  </Field>
                </div>
                <button disabled={recording} className="inline-flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-70 text-white rounded-lg px-4 py-2.5 text-sm font-medium">
                  {recording ? <Spinner /> : <Check className="w-4 h-4" />} Record Payment
                </button>
              </form>
            </Card>
          </div>

          <div className="lg:col-span-3 space-y-4">
            <Card className="p-6">
              <h3 className="font-bold text-slate-900 mb-3">Fee Items — {session}</h3>
              {loading ? (
                <div className="py-8 flex justify-center text-[#0a4da8]"><Spinner className="w-6 h-6" /></div>
              ) : items.length === 0 ? (
                <EmptyState text="No fees set for this session yet." />
              ) : (
                <ul className="divide-y divide-slate-50">
                  {items.map((f) => (
                    <li key={f.id} className="flex items-center gap-3 py-3">
                      <div className="mr-auto min-w-0">
                        <p className="font-medium text-slate-800 truncate">{f.title}</p>
                        <p className="text-xs text-slate-400">{f.class_id ? className(classes, f.class_id) : "All Classes"}{f.term ? ` · ${f.term}` : ""}</p>
                      </div>
                      <span className="font-bold text-slate-900">{formatMoney(Number(f.amount))}</span>
                      <button onClick={() => deleteItem(f)} className="h-8 w-8 inline-flex items-center justify-center rounded-md text-slate-400 hover:text-red-600 hover:bg-red-50" title="Delete fee">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </Card>

            <Card>
              <h3 className="font-bold text-slate-900 px-6 pt-5 pb-2">Recent Payments</h3>
              {payments.length === 0 ? (
                <EmptyState text="No payments recorded yet." />
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm min-w-[600px]">
                    <thead>
                      <tr className="text-left text-xs uppercase tracking-wide text-slate-400 border-b border-slate-100">
                        <th className="py-3 px-5 font-semibold">Student</th>
                        <th className="py-3 px-5 font-semibold">Amount</th>
                        <th className="py-3 px-5 font-semibold">Method</th>
                        <th className="py-3 px-5 font-semibold">Reference</th>
                        <th className="py-3 px-5 font-semibold">Date</th>
                      </tr>
                    </thead>
                    <tbody>
                      {payments.slice(0, 20).map((p) => (
                        <tr key={p.id} className="border-b border-slate-50 last:border-0 hover:bg-slate-50/60">
                          <td className="py-3 px-5 font-medium text-slate-800">{studentName(p.student_id)}</td>
                          <td className="py-3 px-5 font-semibold">{formatMoney(Number(p.amount))}</td>
                          <td className="py-3 px-5 text-slate-500">{p.method}</td>
                          <td className="py-3 px-5 text-slate-500 text-xs">{p.reference}</td>
                          <td className="py-3 px-5 text-slate-500">{new Date(p.created_at).toLocaleDateString()}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------------------------------- Parent --------------------------------- */
function ParentFees({ profile }: { profile: Profile }) {
  const { classes } = useClasses();
  const [session, setSession] = useState(CURRENT_SESSION);
  const [children, setChildren] = useState<Student[]>([]);
  const [items, setItems] = useState<FeeItem[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState<{ type: "err" | "ok"; text: string } | null>(null);
  const [payingFor, setPayingFor] = useState<Student | null>(null);

  const load = async () => {
    const kids = await fetchMyChildren(profile.id);
    setChildren(kids);
    const [{ data: fi }, { data: pm }] = await Promise.all([
      supabase.from("fee_items").select("*"),
      supabase.from("payments").select("*").order("created_at", { ascending: false }),
    ]);
    setItems((fi ?? []) as FeeItem[]);
    setPayments((pm ?? []) as Payment[]);
    setLoading(false);
  };
  useEffect(() => { load(); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const summaryFor = (child: Student) => {
    const due = items
      .filter((f) => f.session === session && (f.class_id === null || f.class_id === child.class_id))
      .reduce((a, f) => a + Number(f.amount), 0);
    const childPayments = payments.filter((p) => p.student_id === child.id && p.status === "Paid");
    const paid = childPayments.reduce((a, p) => a + Number(p.amount), 0);
    return { due, paid, balance: Math.max(0, due - paid), childPayments };
  };

  return (
    <div>
      <PageHeader
        title="School Fees"
        subtitle="View your children's school fees and pay online"
        actions={
          <select className={fieldCls + " w-44"} value={session} onChange={(e) => setSession(e.target.value)}>
            {SESSIONS.map((s) => <option key={s}>{s}</option>)}
          </select>
        }
      />
      <div className="space-y-4">
        <Banner msg={msg} />
        {loading ? (
          <div className="py-14 flex justify-center text-[#0a4da8]"><Spinner className="w-6 h-6" /></div>
        ) : children.length === 0 ? (
          <Card><EmptyState text="No children are linked to your account yet. Please contact the school office." /></Card>
        ) : (
          children.map((child) => {
            const { due, paid, balance, childPayments } = summaryFor(child);
            const feesForChild = items.filter((f) => f.session === session && (f.class_id === null || f.class_id === child.class_id));
            const pct = due > 0 ? Math.min(100, Math.round((paid / due) * 100)) : 0;
            return (
              <Card key={child.id} className="p-6">
                <div className="flex flex-wrap items-center gap-3">
                  <Avatar name={fullName(child)} className="h-11 w-11 text-sm" />
                  <div className="mr-auto min-w-0">
                    <p className="font-semibold text-slate-900">{fullName(child)}</p>
                    <p className="text-xs text-slate-500">{className(classes, child.class_id)} · {child.admission_no}</p>
                  </div>
                  <button
                    onClick={() => setPayingFor(child)}
                    disabled={balance <= 0}
                    className="inline-flex items-center gap-2 bg-[#0a4da8] hover:bg-[#083d86] disabled:opacity-50 text-white rounded-lg px-4 py-2.5 text-sm font-medium"
                  >
                    <CreditCard className="w-4 h-4" /> {balance <= 0 ? "Fully Paid" : "Pay Now"}
                  </button>
                </div>

                <div className="grid grid-cols-3 gap-3 mt-5 text-center">
                  <div className="rounded-xl bg-slate-50 py-3">
                    <p className="text-[11px] uppercase tracking-wide text-slate-400">Total Fees ({session})</p>
                    <p className="font-bold text-slate-900 mt-0.5">{formatMoney(due)}</p>
                  </div>
                  <div className="rounded-xl bg-emerald-50 py-3">
                    <p className="text-[11px] uppercase tracking-wide text-emerald-500">Paid</p>
                    <p className="font-bold text-emerald-700 mt-0.5">{formatMoney(paid)}</p>
                  </div>
                  <div className="rounded-xl bg-amber-50 py-3">
                    <p className="text-[11px] uppercase tracking-wide text-amber-500">Balance</p>
                    <p className="font-bold text-amber-700 mt-0.5">{formatMoney(balance)}</p>
                  </div>
                </div>
                <div className="h-2.5 rounded-full bg-slate-100 mt-3 overflow-hidden">
                  <div className="h-full bg-emerald-500 rounded-full transition-all" style={{ width: `${pct}%` }} />
                </div>

                {feesForChild.length > 0 && (
                  <div className="mt-5">
                    <p className="text-xs font-semibold uppercase tracking-wide text-slate-400 mb-2">Fee Breakdown</p>
                    <ul className="divide-y divide-slate-50 text-sm">
                      {feesForChild.map((f) => (
                        <li key={f.id} className="flex py-2">
                          <span className="mr-auto text-slate-700">{f.title}{f.term ? <span className="text-slate-400"> · {f.term}</span> : null}</span>
                          <span className="font-medium">{formatMoney(Number(f.amount))}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {childPayments.length > 0 && (
                  <div className="mt-5">
                    <p className="text-xs font-semibold uppercase tracking-wide text-slate-400 mb-2">Payment History</p>
                    <ul className="divide-y divide-slate-50 text-sm">
                      {childPayments.map((p) => (
                        <li key={p.id} className="flex flex-wrap gap-2 py-2">
                          <span className="mr-auto text-slate-700">{formatMoney(Number(p.amount))} <span className="text-slate-400">via {p.method}</span></span>
                          <span className="text-xs text-slate-400">{p.reference}</span>
                          <span className="text-xs text-slate-400">{new Date(p.created_at).toLocaleDateString()}</span>
                          <span className="text-[11px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-full px-2 py-0.5">{p.status}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </Card>
            );
          })
        )}
      </div>

      {payingFor && (
        <PayModal
          child={payingFor}
          balance={summaryFor(payingFor).balance}
          parentId={profile.id}
          onClose={() => setPayingFor(null)}
          onDone={(text) => { setMsg({ type: "ok", text }); load(); }}
        />
      )}
    </div>
  );
}

function PayModal({
  child, balance, parentId, onClose, onDone,
}: {
  child: Student;
  balance: number;
  parentId: string;
  onClose: () => void;
  onDone: (msg: string) => void;
}) {
  const [amount, setAmount] = useState(String(balance));
  const [method, setMethod] = useState("Card");
  const [paying, setPaying] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const pay = async (e: FormEvent) => {
    e.preventDefault();
    const value = Number(amount);
    if (!value || value <= 0) { setError("Enter a valid amount."); return; }
    if (value > balance) { setError(`Amount is more than the balance of ${formatMoney(balance)}.`); return; }
    setPaying(true); setError(null);
    // PAYMENT GATEWAY SPOT: when PAYSTACK_PUBLIC_KEY is set, launch the
    // gateway checkout here and record the payment after it succeeds.
    void PAYSTACK_PUBLIC_KEY;
    const reference = generateReference();
    const { error: err } = await supabase.from("payments").insert({
      student_id: child.id, amount: value, method: `${method} (Online)`,
      reference, status: "Paid", paid_by: parentId,
    });
    setPaying(false);
    if (err) setError(friendlyError(err.message));
    else {
      onDone(`Payment of ${formatMoney(value)} for ${fullName(child)} was successful. Reference: ${reference}. Thank you!`);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center">
      <div className="absolute inset-0 bg-slate-900/50" onClick={onClose} />
      <div className="relative bg-white w-full max-w-md rounded-t-2xl sm:rounded-2xl shadow-xl p-6 m-0 sm:m-4">
        <div className="flex items-center gap-3 mb-1">
          <h3 className="font-bold text-slate-900 mr-auto">Pay School Fees</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-700" aria-label="Close"><X className="w-5 h-5" /></button>
        </div>
        <p className="text-sm text-slate-500">{fullName(child)} · Balance <b className="text-slate-800">{formatMoney(balance)}</b></p>

        <form onSubmit={pay} className="mt-5 space-y-4">
          {error && <div className="rounded-lg bg-red-50 border border-red-200 px-4 py-3 text-sm text-red-700">{error}</div>}
          <Field label="Amount (₦)">
            <input type="number" min={1} required className={fieldCls} value={amount} onChange={(e) => setAmount(e.target.value)} />
          </Field>
          <Field label="Payment Method">
            <div className="grid grid-cols-2 gap-2">
              {["Card", "Bank Transfer"].map((m) => (
                <button
                  key={m} type="button" onClick={() => setMethod(m)}
                  className={`rounded-lg border px-3 py-2.5 text-sm font-medium transition ${method === m ? "border-[#0a4da8] bg-blue-50 text-[#0a4da8]" : "border-slate-200 text-slate-600 hover:border-slate-300"}`}
                >
                  {m}
                </button>
              ))}
            </div>
          </Field>
          <button disabled={paying} className="w-full inline-flex justify-center items-center gap-2 bg-[#0a4da8] hover:bg-[#083d86] disabled:opacity-70 text-white rounded-lg py-3 text-sm font-semibold">
            {paying ? <Spinner /> : <CreditCard className="w-4 h-4" />}
            {paying ? "Processing Payment…" : `Pay ${amount ? formatMoney(Number(amount) || 0) : ""}`}
          </button>
          <p className="text-[11px] text-slate-400 text-center leading-relaxed">
            Payments are recorded instantly with a reference number. Live card processing via
            Paystack/Flutterwave can be switched on by adding your gateway public key.
          </p>
        </form>
      </div>
    </div>
  );
}

